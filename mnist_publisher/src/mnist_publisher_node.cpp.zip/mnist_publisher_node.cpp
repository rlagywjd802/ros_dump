#include <ros/ros.h>
#include <opencv2/opencv.hpp>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <image_transport/image_transport.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

int convert_to_int(int i)
{
    unsigned char ch1, ch2, ch3, ch4;
    ch1 = i & 255;
    ch2 = (i >> 8) & 255;
    ch3 = (i >> 16) & 255;
    ch4 = (i >> 24) & 255;

    return((int) ch1 << 24) + ((int)ch2 << 16) + ((int)ch3 << 8) + ch4;
}

bool load_mnist(vector<cv::Mat> &vec)
{
	ifstream file ("/home/hyojeong/catkin_ws/src/mnist_publisher/mnist/t10k-images-idx3-ubyte", ios::binary);
	int magic_number = 0;
	int number_of_images = 0;
	int n_rows = 0;
	int n_cols = 0;

	if(file.is_open())
	{
		ROS_INFO("opened file");

		// read mnist info
		file.read((char*)&magic_number, sizeof(magic_number));
		magic_number = convert_to_int(magic_number);
		file.read((char*)&number_of_images, sizeof(number_of_images));
		number_of_images = convert_to_int(number_of_images);
		file.read((char*)&n_rows, sizeof(n_rows));
		n_rows = convert_to_int(n_rows);
		file.read((char*)&n_cols, sizeof(n_cols));
		n_cols = convert_to_int(n_cols);

		// read mnist image
		for(int i=0; i<number_of_images; ++i)
		{
			cv::Mat tp = cv::Mat::zeros(n_rows, n_cols, CV_8UC1);
			for(int r=0; r<n_rows; ++r)
			{
				for(int c=0; c<n_cols; ++c)
				{
					unsigned char temp = 0;
					file.read((char *)&temp, sizeof(temp));
					tp.at<uchar>(r, c) = (int)temp;
				}
			}
			vec.push_back(tp);
		}

		return true;

	}
	else
	{
		ROS_INFO("cannot open file");
		return false;
	}	
}

int main(int argc, char** argv)
{
	ros::init(argc, argv, "mnist_publisher");
	ros::NodeHandle nh;
	image_transport::ImageTransport it_(nh);
	image_transport::Publisher image_pub = it_.advertise("/digit_image", 1);

	vector<cv::Mat> test_images;
	int flag = load_mnist(test_images);	
	cv_bridge::CvImagePtr cv_ptr(new cv_bridge::CvImage);

	ros::Rate loop_rate(10);
	while(ros::ok())
	{
		ros::Time time = ros::Time::now();
		cv_ptr->encoding = "mono8";	//CV_8UC1, grayscale image
		cv_ptr->header.stamp = time;
		cv_ptr->header.frame_id = "/digit_image";
		cv_ptr->image = test_images[0];
		image_pub.publish(cv_ptr->toImageMsg());

		ROS_INFO("ImageMsg Sent.");
		
		ros::spinOnce();
		loop_rate.sleep();
	}
}